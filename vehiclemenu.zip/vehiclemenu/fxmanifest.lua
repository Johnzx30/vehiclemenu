fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'NativeUI-based Vehicle Interaction System'
version '1.0.0'

client_script '@NativeUI/NativeUI.lua'
client_script 'client.lua'
server_script 'server.lua'
shared_script 'config.lua'