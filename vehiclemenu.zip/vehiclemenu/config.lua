Config = {}

Config.Cooldown = 1000

Config.API = {
    SaveState = "http://localhost:3000/vehicle/state",
    GetState = "http://localhost:3000/vehicle/state"
}