function SaveVehicleState(plate, state)
    PerformHttpRequest(Config.API.SaveState, function(err, text, headers)
        if err == 200 then
            print("State saved successfully")
        else
            print("Failed to save state")
        end
    end, "POST", json.encode(state), {["Content-Type"] = "application/json"})
end