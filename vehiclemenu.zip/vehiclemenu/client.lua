local menu = nil
local lastAction = 0

function CreateVehicleMenu()
    menu = NativeUI.CreateMenu("Vehicle Menu", "~b~Interact with your vehicle")
    _menuPool:Add(menu)

    local engineToggle = NativeUI.CreateItem("Toggle Engine", "Start or stop the engine.")
    local doorControl = NativeUI.CreateItem("Door Control", "Open/Close doors individually.")
    local lockToggle = NativeUI.CreateItem("Lock/Unlock Vehicle", "Secure or unsecure the vehicle.")
    local seatSwitch = NativeUI.CreateItem("Switch Seat", "Change your seat in the vehicle.")

    menu:AddItem(engineToggle)
    menu:AddItem(doorControl)
    menu:AddItem(lockToggle)
    menu:AddItem(seatSwitch)

    menu.OnItemSelect = function(sender, item, index)
        if GetGameTimer() - lastAction < Config.Cooldown then
            notify("~r~Please wait before performing another action.")
            return
        end

        local playerPed = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        if vehicle == 0 then notify("~r~Not in a vehicle.") return end

        if item == engineToggle then
            TriggerServerEvent("vehicle:toggleEngine", VehToNet(vehicle))
        elseif item == doorControl then
            for i = 0, 5 do
                local open = GetVehicleDoorAngleRatio(vehicle, i) > 0.1
                if open then
                    SetVehicleDoorShut(vehicle, i, false)
                else
                    SetVehicleDoorOpen(vehicle, i, false)
                end
            end
            TriggerServerEvent("vehicle:updateState", VehToNet(vehicle), "doors")
        elseif item == lockToggle then
            TriggerServerEvent("vehicle:toggleLock", VehToNet(vehicle))
        elseif item == seatSwitch then
            if GetPedInVehicleSeat(vehicle, -1) == playerPed then
                TaskWarpPedIntoVehicle(playerPed, vehicle, 0)
            else
                TaskWarpPedIntoVehicle(playerPed, vehicle, -1)
            end
        end

        lastAction = GetGameTimer()
    end
end

function notify(msg)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(msg)
    DrawNotification(false, false)
end

_menuPool = NativeUI.CreatePool()
CreateVehicleMenu()
_menuPool:RefreshIndex()

RegisterCommand("vehmenu", function()
    if IsPedInAnyVehicle(PlayerPedId(), false) then
        menu:Visible(not menu:Visible())
    else
        notify("~r~You must be in a vehicle.")
    end
end, false)

RegisterKeyMapping("vehmenu", "Open Vehicle Menu", "keyboard", "F7")

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        _menuPool:ProcessMenus()
    end
end)