RegisterNetEvent("vehicle:toggleEngine")
AddEventHandler("vehicle:toggleEngine", function(vehNetId)
    local vehicle = NetworkGetEntityFromNetworkId(vehNetId)
    if DoesEntityExist(vehicle) then
        local running = GetIsVehicleEngineRunning(vehicle)
        SetVehicleEngineOn(vehicle, not running, false, true)
    end
end)

RegisterNetEvent("vehicle:toggleLock")
AddEventHandler("vehicle:toggleLock", function(vehNetId)
    local vehicle = NetworkGetEntityFromNetworkId(vehNetId)
    if DoesEntityExist(vehicle) then
        local locked = GetVehicleDoorLockStatus(vehicle)
        if locked == 1 then
            SetVehicleDoorsLocked(vehicle, 2)
        else
            SetVehicleDoorsLocked(vehicle, 1)
        end
    end
end)

RegisterNetEvent("vehicle:updateState")
AddEventHandler("vehicle:updateState", function(vehNetId, stateType)
    local vehicle = NetworkGetEntityFromNetworkId(vehNetId)
    if DoesEntityExist(vehicle) then
        local plate = GetVehicleNumberPlateText(vehicle)
        print(("[API] Vehicle %s state updated: %s"):format(plate, stateType))
    end
end)